package com.zeroun.automed

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val sistema = isSystemInDarkTheme()
    var escuro by remember { mutableStateOf(Store.darkTheme(ctx) ?: sistema) }

    MaterialTheme(
        colorScheme = if (escuro) darkColorScheme() else lightColorScheme()
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Home(escuro) {
                escuro = !escuro
                Store.setDarkTheme(ctx, escuro)
            }
        }
    }
}

@Composable
fun Home(escuro: Boolean, onTema: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var acesso by remember { mutableStateOf(Core.acessoAtivo(ctx)) }
    var vinculado by remember { mutableStateOf(Store.deviceId(ctx) != null) }
    var selecionados by remember { mutableStateOf(Store.apps(ctx)) }
    var codigo by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var abrirSelect by remember { mutableStateOf(false) }
    var ocupado by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        acesso = Core.acessoAtivo(ctx)
        vinculado = Store.deviceId(ctx) != null
    }

    LaunchedEffect(vinculado) {
        while (vinculado) {
            withContext(Dispatchers.IO) {
                Core.heartbeat(ctx)
                Core.flush(ctx)
            }

            vinculado = Store.deviceId(ctx) != null
            delay(30_000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Automed Notificações",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f)
            )

            OutlinedButton(onClick = onTema) {
                Text(if (escuro) "☀️" else "🌙")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Acesso às notificações: ${if (acesso) "Ativado" else "Desativado"}",
                    style = MaterialTheme.typography.titleMedium
                )

                if (!acesso) {
                    Text("Conceda o acesso manualmente na tela oficial do Android.")

                    Button(
                        onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    ) {
                        Text("Abrir configurações")
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!vinculado) {
                    Text(
                        "Vincular ao Discord",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Text(
                        "No Discord: /central → Gmail e pagamentos → Vincular aplicativo."
                    )

                    Text("Servidor: automed-api.shardweb.app")

                    OutlinedTextField(
                        value = codigo,
                        onValueChange = {
                            codigo = it.uppercase().take(8)
                        },
                        label = {
                            Text("Código de vinculação")
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        enabled = !ocupado && codigo.length >= 8,
                        onClick = {
                            ocupado = true

                            scope.launch {
                                val r = withContext(Dispatchers.IO) {
                                    Core.vincular(
                                        ctx,
                                        "https://automed-api.shardweb.app",
                                        codigo
                                    )
                                }

                                msg = r
                                vinculado = Store.deviceId(ctx) != null

                                if (vinculado) {
                                    codigo = ""
                                }

                                ocupado = false
                            }
                        }
                    ) {
                        Text("Vincular")
                    }
                } else {
                    Text(
                        "Celular vinculado",
                        style = MaterialTheme.typography.titleMedium
                    )

                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                msg = withContext(Dispatchers.IO) {
                                    Core.desvincular(ctx)
                                }

                                vinculado = Store.deviceId(ctx) != null
                            }
                        }
                    ) {
                        Text("Desvincular")
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Aplicativos monitorados ${selecionados.size}/3",
                    style = MaterialTheme.typography.titleMedium
                )

                OutlinedButton(
                    onClick = {
                        abrirSelect = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Selecionar aplicativos")
                    Spacer(Modifier.weight(1f))
                    Text("▾")
                }

                selecionados.forEach {
                    Text("• ${it.appName}")
                }
            }
        }

        Text(
            "Privacidade: somente notificações dos aplicativos escolhidos acima são lidas e enviadas ao servidor. " +
                "As demais são ignoradas neste aparelho e nunca saem dele.",
            style = MaterialTheme.typography.bodySmall
        )

        if (msg.isNotBlank()) {
            Text(
                msg,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }

    if (abrirSelect) {
        SeletorApps(
            selecionados,
            onFechar = {
                abrirSelect = false
            }
        ) { novo ->
            selecionados = novo
            Store.setApps(ctx, novo)

            scope.launch(Dispatchers.IO) {
                Core.heartbeat(ctx, "apps")
            }
        }
    }
}

@Composable
fun SeletorApps(
    atual: List<SelApp>,
    onFechar: () -> Unit,
    onMudou: (List<SelApp>) -> Unit
) {
    val ctx = LocalContext.current

    var apps by remember {
        mutableStateOf<List<AppInfo>?>(null)
    }

    var sel by remember {
        mutableStateOf(atual)
    }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) {
            AppsRepo.listar(ctx)
        }
    }

    Dialog(onDismissRequest = onFechar) {
        Surface(
            shape = MaterialTheme.shapes.large,
            tonalElevation = 6.dp
        ) {
            Column(
                Modifier
                    .padding(16.dp)
                    .heightIn(max = 560.dp)
            ) {
                Text(
                    "Aplicativos monitorados ${sel.size}/3",
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(Modifier.height(8.dp))

                val lista = apps

                if (lista == null) {
                    CircularProgressIndicator()
                } else {
                    LazyColumn(
                        Modifier.weight(1f, fill = false)
                    ) {
                        items(
                            lista,
                            key = { it.packageName }
                        ) { a ->

                            val marcado = sel.any {
                                it.packageName == a.packageName
                            }

                            val alternar: () -> Unit = {
                                if (marcado) {
                                    sel = sel.filter {
                                        it.packageName != a.packageName
                                    }

                                    onMudou(sel)
                                } else if (sel.size >= 3) {
                                    Toast.makeText(
                                        ctx,
                                        "O limite é 3 aplicativos.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    sel = sel + SelApp(
                                        a.packageName,
                                        a.name
                                    )

                                    onMudou(sel)
                                }
                            }

                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        alternar()
                                    }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                a.icon?.let {
                                    Image(
                                        bitmap = it,
                                        contentDescription = null,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                Spacer(Modifier.width(12.dp))

                                Text(
                                    a.name,
                                    Modifier.weight(1f)
                                )

                                Checkbox(
                                    checked = marcado,
                                    onCheckedChange = null
                                )
                            }
                        }
                    }
                }

                TextButton(
                    onClick = onFechar,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Concluir")
                }
            }
        }
    }
}