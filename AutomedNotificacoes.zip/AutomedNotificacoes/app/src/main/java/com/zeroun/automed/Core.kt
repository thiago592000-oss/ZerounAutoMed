package com.zeroun.automed

import android.content.Context
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

object Core {
    private val mutex = Mutex()
    private const val MAX_FILA = 30
    private const val MAX_IDADE_MS = 25 * 60 * 1000L

    fun acessoAtivo(c: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    private fun chaveLocal(o: JSONObject) =
        "${o.optString("packageName")}|${o.optString("notificationId")}|${o.optLong("timestamp")}"

    fun vincular(c: Context, servidor: String, codigo: String): String {
        if (!servidor.startsWith("http://") && !servidor.startsWith("https://"))
            return "Informe o endereço completo (http://... ou https://...)."
        Store.setApiBase(c, servidor)
        return try {
            val r = Api.call(c, "vincular", JSONObject().put("codigo", codigo.trim()).put("nome", Build.MODEL), false)
            val j = r.json
            if (r.code == 200 && j?.optBoolean("ok") == true) {
                Store.setDevice(c, j.getString("deviceId"), j.getString("token"))
                heartbeat(c, "apps")
                "Celular vinculado com sucesso."
            } else {
                val m = j?.optString("msg")
                if (!m.isNullOrBlank()) m else "Falha ao vincular (${r.code})."
            }
        } catch (e: Exception) {
            "Sem conexão com o servidor."
        }
    }

    fun desvincular(c: Context): String {
        try { Api.call(c, "desvincular", JSONObject(), true) } catch (_: Exception) {}
        Store.clearDevice(c)
        return "Celular desvinculado."
    }

    fun heartbeat(c: Context, rota: String = "heartbeat") {
        if (Store.deviceId(c) == null) return
        try {
            val apps = JSONArray()
            Store.apps(c).forEach { apps.put(JSONObject().put("packageName", it.packageName).put("appName", it.appName)) }
            val enviadas = Store.removidasPendentes(c)
            val body = JSONObject()
                .put("acessoNotificacoes", acessoAtivo(c))
                .put("apps", apps)
                .put("removidas", JSONArray(enviadas))
            val r = Api.call(c, rota, body, true)
            when (r.code) {
                401 -> Store.clearDevice(c)
                200 -> {
                    Store.limparRemovidas(c, enviadas)
                    aplicarRemocoes(c, r.json?.optJSONArray("remover"))
                }
            }
        } catch (_: Exception) {
        }
    }

    /** Remove SOMENTE as notificações cuja chave o servidor mandou. Erros nunca derrubam o app. */
    private fun aplicarRemocoes(c: Context, arr: JSONArray?) {
        if (arr == null || arr.length() == 0) return
        val servico = NotifService.instance ?: return
        for (i in 0 until arr.length()) {
            val chave = arr.optString(i)
            if (chave.isBlank()) continue
            try { servico.cancelNotification(chave) } catch (_: Exception) {}
            Store.addRemovida(c, chave)
        }
    }

    suspend fun enviar(c: Context, item: JSONObject) = mutex.withLock {
        val k = chaveLocal(item)
        if (Store.jaEnviada(c, k)) return@withLock
        val fila = Store.fila(c).toMutableList()
        if (fila.none { chaveLocal(it) == k }) {
            fila.add(item)
            while (fila.size > MAX_FILA) fila.removeAt(0)
            Store.salvarFila(c, fila)
        }
        flushLocked(c)
    }

    suspend fun flush(c: Context) = mutex.withLock { flushLocked(c) }

    private fun flushLocked(c: Context) {
        if (Store.deviceId(c) == null) return
        val agora = System.currentTimeMillis()
        val fila = Store.fila(c).filter { agora - it.optLong("timestamp") <= MAX_IDADE_MS }.toMutableList()
        val iter = fila.iterator()
        loop@ while (iter.hasNext()) {
            val item = iter.next()
            try {
                val r = Api.call(c, "notificacao", item, true)
                when {
                    r.code == 200 -> {
                        Store.marcarEnviada(c, chaveLocal(item))
                        iter.remove()
                        aplicarRemocoes(c, r.json?.optJSONArray("remover"))
                    }
                    r.code == 401 -> { Store.clearDevice(c); fila.clear(); break@loop }
                    r.code == 429 || r.code >= 500 -> break@loop
                    else -> iter.remove()
                }
            } catch (e: Exception) {
                break@loop
            }
        }
        Store.salvarFila(c, fila)
    }
}