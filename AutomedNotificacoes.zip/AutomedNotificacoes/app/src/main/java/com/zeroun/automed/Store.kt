package com.zeroun.automed

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

data class SelApp(val packageName: String, val appName: String)

object Store {
    @Volatile private var sec: SharedPreferences? = null

    private fun p(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("automed_prefs", Context.MODE_PRIVATE)

    @Synchronized
    private fun s(c: Context): SharedPreferences {
        sec?.let { return it }
        val k = MasterKey.Builder(c.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val e = EncryptedSharedPreferences.create(
            c.applicationContext, "automed_secure", k,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        sec = e
        return e
    }

    // ---- tema ----
    fun darkTheme(c: Context): Boolean? = p(c).let { if (it.contains("dark")) it.getBoolean("dark", false) else null }
    fun setDarkTheme(c: Context, v: Boolean) { p(c).edit().putBoolean("dark", v).apply() }

    // ---- servidor ----
    fun apiBase(c: Context): String = p(c).getString("api", null) ?: BuildConfig.API_BASE
    fun setApiBase(c: Context, v: String) { p(c).edit().putString("api", v.trim().trimEnd('/')).apply() }

    // ---- credencial do dispositivo (criptografada) ----
    fun deviceId(c: Context): String? = try { s(c).getString("deviceId", null) } catch (e: Exception) { null }
    fun token(c: Context): String? = try { s(c).getString("token", null) } catch (e: Exception) { null }
    @Synchronized fun setDevice(c: Context, id: String, token: String) {
        s(c).edit().putString("deviceId", id).putString("token", token).apply()
    }
    @Synchronized fun clearDevice(c: Context) {
        try { s(c).edit().clear().apply() } catch (_: Exception) {}
        p(c).edit().remove("fila").remove("enviadas").remove("removidas").apply()
    }

    // ---- apps selecionados (máx. 3) ----
    fun apps(c: Context): List<SelApp> = try {
        val a = JSONArray(p(c).getString("apps", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); SelApp(o.getString("p"), o.getString("n")) }
    } catch (e: Exception) { emptyList() }
    @Synchronized fun setApps(c: Context, l: List<SelApp>) {
        val a = JSONArray()
        l.take(3).forEach { a.put(JSONObject().put("p", it.packageName).put("n", it.appName)) }
        p(c).edit().putString("apps", a.toString()).apply()
    }

    // ---- fila offline ----
    fun fila(c: Context): List<JSONObject> = try {
        val a = JSONArray(p(c).getString("fila", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }
    } catch (e: Exception) { emptyList() }
    @Synchronized fun salvarFila(c: Context, l: List<JSONObject>) {
        val a = JSONArray()
        l.forEach { a.put(it) }
        p(c).edit().putString("fila", a.toString()).apply()
    }

    // ---- idempotência local (já enviadas, 30 min) ----
    private fun enviadasObj(c: Context): JSONObject =
        try { JSONObject(p(c).getString("enviadas", "{}")) } catch (e: Exception) { JSONObject() }
    fun jaEnviada(c: Context, k: String): Boolean = enviadasObj(c).has(k)
    @Synchronized fun marcarEnviada(c: Context, k: String) {
        val o = enviadasObj(c)
        val agora = System.currentTimeMillis()
        val velhas = o.keys().asSequence().filter { o.optLong(it) < agora - 30 * 60 * 1000L }.toList()
        velhas.forEach { o.remove(it) }
        o.put(k, agora)
        p(c).edit().putString("enviadas", o.toString()).apply()
    }

    // ---- remoções realizadas, aguardando confirmação ao servidor ----
    fun removidasPendentes(c: Context): List<String> = try {
        val a = JSONArray(p(c).getString("removidas", "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }
    @Synchronized fun addRemovida(c: Context, k: String) {
        val l = removidasPendentes(c).toMutableList()
        if (!l.contains(k)) l.add(k)
        p(c).edit().putString("removidas", JSONArray(l.takeLast(50)).toString()).apply()
    }
    @Synchronized fun limparRemovidas(c: Context, enviadas: List<String>) {
        val l = removidasPendentes(c).filterNot { enviadas.contains(it) }
        p(c).edit().putString("removidas", JSONArray(l).toString()).apply()
    }
}