package com.zeroun.automed

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

class NotifService : NotificationListenerService() {
    companion object {
        @Volatile var instance: NotifService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onListenerConnected() {
        instance = this
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                try {
                    Core.heartbeat(applicationContext)
                    Core.flush(applicationContext)
                } catch (_: Exception) {}
                delay(30_000)
            }
        }
    }

    override fun onListenerDisconnected() {
        job?.cancel()
        instance = null
        try { requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        try {
            val ctx = applicationContext
            if (sbn == null || Store.deviceId(ctx) == null) return
            val pkg = sbn.packageName ?: return
            // FILTRO LOCAL: apps não selecionados são ignorados e nunca saem do aparelho
            val app = Store.apps(ctx).firstOrNull { it.packageName == pkg } ?: return
            val n = sbn.notification ?: return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            val ex = n.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().take(200)
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
                ?.toString().orEmpty().take(600)
            if (title.isBlank() && text.isBlank()) return
            val item = JSONObject()
                .put("notificationId", sbn.key)
                .put("packageName", pkg)
                .put("appName", app.appName)
                .put("title", title)
                .put("text", text)
                .put("timestamp", sbn.postTime)
            scope.launch { try { Core.enviar(ctx, item) } catch (_: Exception) {} }
        } catch (_: Exception) {
        }
    }
}